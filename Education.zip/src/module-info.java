//module Education {
////	requires jdk.jdi;
////	requires java.naming;
////	requires java.sql;
////	requires java.desktop;
//}